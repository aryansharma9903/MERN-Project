import { ChatState } from '../../Context/chatProvider';
import React, { useState, useEffect } from 'react';
import './SingleChat.css';
import axios from 'axios';
import io from 'socket.io-client';

const ENDPOINT = 'http://localhost:5000';
let socket, selectedChatCompare;

const SingleChat = ({ fetchAgain, setFetchAgain }) => {
  const { user, selectedChat } = ChatState();
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [socketConnected, setSocketConnected] = useState(false);

  // Connect to socket server on mount
  useEffect(() => {
    socket = io(ENDPOINT);
    socket.emit("setup", user);
    socket.on("connected", () => setSocketConnected(true));
  }, []);

  // Join selected chat room
  useEffect(() => {
    if (!selectedChat) return;

    const fetchMessages = async () => {
      try {
        const config = {
          headers: {
            Authorization: `Bearer ${user.token}`,
          },
        };
        const { data } = await axios.get(`/api/message/${selectedChat._id}`, config);
        setMessages(data);
        socket.emit("join chat", selectedChat._id);
        selectedChatCompare = selectedChat;
      } catch (error) {
        console.error("Failed to load messages", error);
      }
    };

    fetchMessages();
  }, [selectedChat]);

  // Handle incoming messages
  useEffect(() => {
    socket.on("message received", (newMessageReceived) => {
      if (!selectedChatCompare || selectedChatCompare._id !== newMessageReceived.chat._id) {
        // optionally show notification
      } else {
        setMessages((prev) => [...prev, newMessageReceived]);
      }
    });
  });

  // Send a new message
  const sendMessage = async (event) => {
    if (event.key === 'Enter' && newMessage.trim()) {
      try {
        const config = {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${user.token}`,
          },
        };

        const { data } = await axios.post(
          '/api/message',
          {
            content: newMessage,
            chatId: selectedChat._id,
          },
          config
        );

        socket.emit("new message", data); // Notify others via socket
        setMessages([...messages, data]);
        setNewMessage("");
      } catch (error) {
        console.error("Message send failed", error);
      }
    }
  };

  const typingHandler = (e) => {
    setNewMessage(e.target.value);
  };

  return (
    <div className='chat-message'>
      <div className='messages'>
        {messages.map((msg, i) => (
          <div
            key={i}
            className={msg.sender._id === user._id ? 'my-msg' : 'other-msg'}
          >
            <strong>{msg.sender.name}:</strong> {msg.content}
          </div>
        ))}
      </div>

      <input
        type="text"
        placeholder='Enter a message...'
        value={newMessage}
        onChange={typingHandler}
        onKeyDown={sendMessage}
      />
    </div>
  );
};

export default SingleChat;
